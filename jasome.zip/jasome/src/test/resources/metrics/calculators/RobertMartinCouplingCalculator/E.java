package org.whatever.stuff2;

import org.whatever.stuff.*;

public class E {
    public void usesD() {
        D d = new D();
        System.out.println(d);
    }
}
