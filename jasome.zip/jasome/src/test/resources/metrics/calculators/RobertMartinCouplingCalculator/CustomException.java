package org.whatever.stuff;

public class CustomException extends Exception {

}
