package org.whatever.stuff;

import org.whatever.stuff2.*;

public class A {
    public void wee() {
        System.out.println(D.utilMethod(10));
    }
}
