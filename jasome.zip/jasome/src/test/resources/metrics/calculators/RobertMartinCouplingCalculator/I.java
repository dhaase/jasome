package org.whatever.stuff;

import org.whatever.stuff2.*;

public interface I {

}

