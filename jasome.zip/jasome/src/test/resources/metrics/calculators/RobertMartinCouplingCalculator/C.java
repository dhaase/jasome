package org.whatever.stuff2;

import org.whatever.stuff.*;

public class C {
    private A field;

    public A returnsA() {
        return new A();
    }
}
