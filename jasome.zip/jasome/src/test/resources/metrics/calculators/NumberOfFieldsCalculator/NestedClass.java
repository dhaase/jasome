package org.whatever.stuff;

class Example {
    public int stuff;
    public static int stuff2;
    private long stuff3;

    public void method() {

    }

    private void method2() {

    }

    static void method3() {

    }

    public static class Inner {
        public int inner;
        private static long innerlong;

        public void innerMethod() {

        }
    }
}
