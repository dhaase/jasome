package org.whatever.stuff;

class A {

}

interface I {

}

interface J extends I {

}

interface K extends J {

}

class ClassX extends A implements K {

}

class ClassY extends A {

}
